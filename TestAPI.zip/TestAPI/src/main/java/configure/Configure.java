package configure;

public class Configure {

}
