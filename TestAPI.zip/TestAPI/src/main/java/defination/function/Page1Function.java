package defination.function;

public class Page1Function {

}
