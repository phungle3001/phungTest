package utility;

public class Constant {
	public static final String VALID_EMAIL_ACC01 = "eve.holt@reqres.in";
	public static final String VALID_PASS_ACC01 = "cityslicka";
	public static final String VALID_EMAIL_ACC02 = "eve.holt@reqres.in";
	public static final String NEW_NAME = "Phung";
	public static final String NEW_JOB = "Tester";
	public static final String EDIT_NAME = "PhungEdit";
	public static final String EDIT_JOB = "TesterEdit";
	public static final String GET_ALL_USER_URL = "https://reqres.in/api/users";
	public static final String GET_ALL_USER_PAGE1_URL = "https://reqres.in/api/users?page=1";
	public static final String GET_ALL_USER_PAGE2_URL = "https://reqres.in/api/users?page=2";
	public static final String INVALID_GET_ALL_USER_PAGE1_URL = "https://reqres.in//api/users?page=1";
	public static final String CREATE_USER_URL = "https://reqres.in/api/users/";
	public static final String INVALID_CREATE_USER_URL = "https://reqres.in/api//users/";
	public static final String LOGIN_URL = "https://reqres.in/api/login";
	public static final String MESG_ERR_MISSING_PASSWORD = "Missing password";
	
}
