package testSuite;

import org.json.JSONObject;
import org.junit.Test;


import Test.TestAPI.*;
import apiFunction.APIFunction;

import static org.junit.Assert.*;
import java.util.HashMap;
import java.util.Map;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import utility.*;

public class E2E_Test01 {
	String emailRequest = "eve.holt@reqres.in";
	String passRequest = "cityslicka";

	@Test
	public void TC_01() {

		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC02,"").contentType("application/json")
				.accept("application/json");
		// Input to Request Body without password
		APIFunction apiFunction = new APIFunction();
		apiFunction.inputRequestBodyAPILogin(httpRequest, Constant.VALID_EMAIL_ACC02, "");
		// Send Request
		Response res = httpRequest.post(Constant.LOGIN_URL);
		// Verify Response
		// Check Status Code = 400
		int statusCode = res.getStatusCode();
		//assertTrue(statusCode == 400);
		System.out.println("Status code: "+ statusCode );
		// Check 'error': "Missing password"
		String errorMessage = apiFunction.getAttributeTypeStringFromResponse(res, "error");
		assertTrue(errorMessage.equalsIgnoreCase(Constant.MESG_ERR_MISSING_PASSWORD));
		System.out.println("errorMessage: "+ errorMessage );

	}

	@Test
	public void TC_02() {

		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01).contentType("application/json")
				.accept("application/json");
		// Input to Request Body
		APIFunction apiFunction = new APIFunction();
		apiFunction.inputRequestBodyAPILogin(httpRequest, Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01);
		// Send Request
		Response res = httpRequest.post(Constant.LOGIN_URL);
		// Verify Response
		// Check Status Code = 200
		int statusCode = res.getStatusCode();
		assertTrue(statusCode == 200);
		System.out.println("Status code: "+ statusCode );
		// Check 'token' attribute existing and not null
		String tokenValue = apiFunction.getAttributeTypeStringFromResponse(res, "token");
		assertTrue(!tokenValue.isEmpty());
		System.out.println("tokenValue: "+ tokenValue );
	}

}
