package testSuite;

import static org.junit.Assert.*;
import org.json.JSONObject;
import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import utility.*;
import apiFunction.APIFunction;

public class E2E_Test02 {
	String getIDOfNewUser = "";

	@Test
	public void TC3() {
		// httpRequest
		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01).contentType("application/json")
				.accept("application/json");
		// Get token as valueToken
		APIFunction apiFunction = new APIFunction();
		String valueToken = apiFunction.getTokenValueAfterLoginSuccess(httpRequest, Constant.VALID_EMAIL_ACC01,
				Constant.VALID_PASS_ACC01);
		// Send GET Request + Authorization: Bear valueToken in Header
		Response response = apiFunction.responseGETMethodIncludedToken(Constant.GET_ALL_USER_PAGE1_URL, valueToken);

		// Verify Response
		// Status code = 200
		int statusCode = response.getStatusCode();
		assertTrue(statusCode == 200);

		// Get value of 'page' as 1
		int pageNumber = apiFunction.getAttributeTypeIntFromResponse(response, "page");
		assertTrue(pageNumber == 1);
		System.out.println("pageNumber: " + pageNumber);

		// Print all RESPONSE content
		System.out.println("=====================");
		System.out.println("Run TC03: GET LISTUSERS - Verify to get list user in page 1 successfully");
		System.out.println(response.statusLine());
		System.out.println(response.getBody().asPrettyString());
	}

	@Test
	public void TC4() {
		// httpRequest
		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01).contentType("application/json")
				.accept("application/json");
		// Get token as valueToken
		APIFunction apiFunction = new APIFunction();
		String valueToken = apiFunction.getTokenValueAfterLoginSuccess(httpRequest, Constant.VALID_EMAIL_ACC01,
				Constant.VALID_PASS_ACC01);
		// Send GET Request + Authorization: Bear valueToken in Header
		Response response = apiFunction.responseGETMethodIncludedToken(Constant.GET_ALL_USER_PAGE2_URL, valueToken);

		// Verify Response
		// Status code = 200
		int statusCode = response.getStatusCode();
		assertTrue(statusCode == 200);

		// Get value of 'page' as 2
		int pageNumber = apiFunction.getAttributeTypeIntFromResponse(response, "page");
		assertTrue(pageNumber == 2);
		System.out.println("pageNumber: " + pageNumber);

		// Print all RESPONSE content
		System.out.println("=====================");
		System.out.println("Run TC04: GET LISTUSERS - Verify to get list user in page 2 successfully");
		System.out.println(response.statusLine());
		System.out.println(response.getBody().asPrettyString());
	}

	@Test
	public void TC5() {
		// httpRequest
		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01).contentType("application/json")
				.accept("application/json");
		// Get token as valueToken
		APIFunction apiFunction = new APIFunction();
		String valueToken = apiFunction.getTokenValueAfterLoginSuccess(httpRequest, Constant.VALID_EMAIL_ACC01,
				Constant.VALID_PASS_ACC01);
		// Send GET Request + Authorization: Bear valueToken in Header
		Response response = apiFunction.responseGETMethodIncludedToken(Constant.INVALID_GET_ALL_USER_PAGE1_URL,
				valueToken);

		// Verify Response
		// Status code = 200
		int statusCode = response.getStatusCode();
		assertTrue(statusCode == 404);

		// Print all RESPONSE content
		System.out.println("=====================");
		System.out
				.println("Run TC05: GET LISTUSERS - Verify to get list user in page 2 unsuccessfully due to wrong url");
		System.out.println(response.statusLine());
		System.out.println(response.getBody().asPrettyString());
	}

	@Test
	public void TC6() {
		// httpRequest
		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01).contentType("application/json")
				.accept("application/json");
		// Get token as valueToken
		APIFunction apiFunction = new APIFunction();
		String valueToken = apiFunction.getTokenValueAfterLoginSuccess(httpRequest, Constant.VALID_EMAIL_ACC01,
				Constant.VALID_PASS_ACC01);
		// Send POST Request + Authorization: Bear valueToken in Header
		apiFunction.inputRequestBodyAPICreateNewUser(httpRequest,Constant.NEW_NAME,Constant.NEW_JOB);
		Response response = apiFunction.responsePOSTMethodIncludedToken(Constant.CREATE_USER_URL, valueToken);
		
		// Verify Response
		// Status code = 201
		int statusCode = response.getStatusCode();
		assertTrue(statusCode == 201);
		// Verify “id” attribute and it’s not null - Record value
		// of "id" to getIDOfNewUser
		 getIDOfNewUser = apiFunction.getAttributeTypeStringFromResponse(response, "id");
		assertTrue(!getIDOfNewUser.isEmpty());
		System.out.println("id: " + getIDOfNewUser);
		
	

		// Print all RESPONSE content
		System.out.println("=====================");
		System.out.println("Run TC06: POST CREATE - Verify to create new user successfully");
		System.out.println(response.statusLine());
		System.out.println(response.getBody().asPrettyString());

	}

	@Test
	public void TC7() {
		// httpRequest
		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01).contentType("application/json")
				.accept("application/json");
		// Get token as valueToken
		APIFunction apiFunction = new APIFunction();
		String valueToken = apiFunction.getTokenValueAfterLoginSuccess(httpRequest, Constant.VALID_EMAIL_ACC01,
				Constant.VALID_PASS_ACC01);
		// Send POST Request with bad request data in HEADER
		apiFunction.inputRequestBodyAPICreateNewUser(httpRequest,Constant.NEW_NAME,Constant.NEW_JOB);
		Response response = apiFunction.responsePOSTMethodSendBadRequestHeader(Constant.CREATE_USER_URL);
	
		// Verify Response
		// Status code = 400
		int statusCode = response.getStatusCode();
		assertTrue(statusCode == 400);
		
		// Print all RESPONSE content
		System.out.println("=====================");
		System.out.println("Run TC07: POST CREATE - Verify to create new user unsuccessfully due to Bad Request");
		System.out.println(response.statusLine());
		System.out.println(response.getBody().asPrettyString());

	}


	@Test
	public void TC8() {
		// httpRequest
		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01).contentType("application/json")
				.accept("application/json");
		// Get token as valueToken
		APIFunction apiFunction = new APIFunction();
		String valueToken = apiFunction.getTokenValueAfterLoginSuccess(httpRequest, Constant.VALID_EMAIL_ACC01,
				Constant.VALID_PASS_ACC01);
		// Send POST Request + Authorization: Bear valueToken in Header
		apiFunction.inputRequestBodyAPICreateNewUser(httpRequest, Constant.NEW_NAME, Constant.NEW_JOB);
		Response response = apiFunction.responsePOSTMethodIncludedToken(Constant.INVALID_CREATE_USER_URL, valueToken);

		// Verify Response
		// Status code = 404
		int statusCode = response.getStatusCode();
		assertTrue(statusCode == 404);

		// Print all RESPONSE content
		System.out.println("=====================");
		System.out.println("Run TC08: POST CREATE - Verify to create new unsuccessfully due to wrong url");
		System.out.println(response.statusLine());
		System.out.println(response.getBody().asPrettyString());

	}

	@Test
	public void TC9() {
		// httpRequest
		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01).contentType("application/json")
				.accept("application/json");
		// Get token as valueToken
		APIFunction apiFunction = new APIFunction();
		String valueToken = apiFunction.getTokenValueAfterLoginSuccess(httpRequest, Constant.VALID_EMAIL_ACC01,
				Constant.VALID_PASS_ACC01);
		// Send PUT Request - Edit Name only;
		apiFunction.inputRequestBodyAPIEditNewUser(httpRequest, Constant.EDIT_NAME,"");
		Response response = apiFunction.responsePUTMethodIncludedToken(Constant.CREATE_USER_URL+getIDOfNewUser, valueToken);

		// Verify Response
		// Status code = 200
		int statusCode = response.getStatusCode();
		assertTrue(statusCode == 200);

		// Print all RESPONSE content
		System.out.println("=====================");
		System.out.println("Run TC09: PUT UPDATE - Verify to update name successfully");
		System.out.println(response.statusLine());
		System.out.println(response.getBody().asPrettyString());

	}

	@Test
	public void TC10() {
		// httpRequest
		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01).contentType("application/json")
				.accept("application/json");
		// Get token as valueToken
		APIFunction apiFunction = new APIFunction();
		String valueToken = apiFunction.getTokenValueAfterLoginSuccess(httpRequest, Constant.VALID_EMAIL_ACC01,
				Constant.VALID_PASS_ACC01);
		// Send PUT Request - Edit Name only;
		apiFunction.inputRequestBodyAPIEditNewUser(httpRequest, "", Constant.EDIT_JOB);
		Response response = apiFunction.responsePUTMethodIncludedToken(Constant.CREATE_USER_URL+getIDOfNewUser, valueToken);

		// Verify Response
		// Status code = 200
		int statusCode = response.getStatusCode();
		assertTrue(statusCode == 200);

		// Print all RESPONSE content
		System.out.println("=====================");
		System.out.println("Run TC10: PUT UPDATE - Verify to update job successfully");
		System.out.println(response.statusLine());
		System.out.println(response.getBody().asPrettyString());

	}

	@Test
	public void TC11() {
		// httpRequest
		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01).contentType("application/json")
				.accept("application/json");
		// Get token as valueToken
		APIFunction apiFunction = new APIFunction();
		String valueToken = apiFunction.getTokenValueAfterLoginSuccess(httpRequest, Constant.VALID_EMAIL_ACC01,
				Constant.VALID_PASS_ACC01);
		// Send PUT Request - Edit Name only;
		apiFunction.inputRequestBodyAPIEditNewUser(httpRequest, "", Constant.EDIT_JOB);
		Response response = apiFunction.responsePUTMethodIncludedToken(Constant.INVALID_CREATE_USER_URL+getIDOfNewUser, valueToken);

		// Verify Response
		// Status code = 404
		int statusCode = response.getStatusCode();
		assertTrue(statusCode == 404);

		// Print all RESPONSE content
		System.out.println("=====================");
		System.out.println("Run TC11: PUT UPDATE - Verify to update unsuccessfully due to wrong url");
		System.out.println(response.statusLine());
		System.out.println(response.getBody().asPrettyString());

	}

	@Test
	public void TC12() {
		// httpRequest
		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01).contentType("application/json")
				.accept("application/json");
		// Get token as valueToken
		APIFunction apiFunction = new APIFunction();
		String valueToken = apiFunction.getTokenValueAfterLoginSuccess(httpRequest, Constant.VALID_EMAIL_ACC01,
				Constant.VALID_PASS_ACC01);
		// Send DELETE Request 
		Response response = apiFunction.responseDELETEMethodIncludedToken(Constant.CREATE_USER_URL + getIDOfNewUser,
				valueToken);

		// Verify Response
		// Status code = 204
		int statusCode = response.getStatusCode(); 
		assertTrue(statusCode == 204);

		// Print all RESPONSE content
		System.out.println("=====================");
		System.out.println("Run TC12: DELETE DELETE - Verify to delete existing user successfully");
		System.out.println(response.statusLine());
		System.out.println(response.getBody().asPrettyString());
	}

	@Test
	public void TC13() {
		// httpRequest
		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01).contentType("application/json")
				.accept("application/json");
		// Get token as valueToken
		APIFunction apiFunction = new APIFunction();
		String valueToken = apiFunction.getTokenValueAfterLoginSuccess(httpRequest, Constant.VALID_EMAIL_ACC01,
				Constant.VALID_PASS_ACC01);
		// Send DELETE Request
		Response response = apiFunction.responseDELETEMethodIncludedToken(Constant.INVALID_CREATE_USER_URL + getIDOfNewUser,
				valueToken);

		// Verify Response
		// Status code = 404
		
		int statusCode = response.getStatusCode();
		assertTrue(statusCode == 404);

		// Print all RESPONSE content
		System.out.println("=====================");
		System.out.println("Run TC13: DELETE DELETE - Verify to delete unsuccessfully due to wrong url");
		System.out.println(response.statusLine());
		System.out.println(response.getBody().asPrettyString());

	}

	@Test
	public void TC14() {
		// httpRequest
		RequestSpecification httpRequest = RestAssured.given().auth()
				.basic(Constant.VALID_EMAIL_ACC01, Constant.VALID_PASS_ACC01).contentType("application/json")
				.accept("application/json");
		// Get token as valueToken
		APIFunction apiFunction = new APIFunction();
		String valueToken = apiFunction.getTokenValueAfterLoginSuccess(httpRequest, Constant.VALID_EMAIL_ACC01,
				Constant.VALID_PASS_ACC01);
		// Send POST Request with bad request data in HEADER
		apiFunction.inputRequestBodyAPICreateNewUser(httpRequest, Constant.NEW_NAME, Constant.NEW_JOB);
		Response response = apiFunction.responseDELETEMethodSendBadRequestHeader(Constant.CREATE_USER_URL+getIDOfNewUser);

		// Verify Response
		// Status code = 400
		int statusCode = response.getStatusCode();
		assertTrue(statusCode == 400);

		// Print all RESPONSE content
		System.out.println("=====================");
		System.out.println("Run TC14: DELETE DELETE - Verify to delete user unsuccessfully due to Bad request");
		System.out.println(response.statusLine());
		System.out.println(response.getBody().asPrettyString());

	}

}
