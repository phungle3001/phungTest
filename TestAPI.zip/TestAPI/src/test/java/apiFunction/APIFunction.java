package apiFunction;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONObject;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import Test.TestAPI.*;

public class APIFunction {

	public String getTokenValueAfterLoginSuccess(RequestSpecification httpRequest ,String email, String password) {		
				
		// Request Body
		JSONObject requestParams = new JSONObject();
		requestParams.put("email", email);
		requestParams.put("password", password);
		httpRequest.body(requestParams.toString());
		// Login
		Response res = httpRequest.post("https://reqres.in/api/login");
		// Get value of 'token'
		JsonPath j = res.getBody().jsonPath();
		String tokenValue = j.get("token");
		System.out.println("token =" + tokenValue);
		return tokenValue;

	}

	public Response responseGETMethodIncludedToken(String url, String tokenValue) {
		Response resp = RestAssured.given().header("Authorization", "Bearer " + tokenValue).get(url);
		return 		resp;
	}
	public Response responsePOSTMethodIncludedToken(String url, String tokenValue) {
		Response resp = RestAssured.given().header("Authorization", "Bearer " + tokenValue).and().header("Content-Type","application/json").post(url);
		return 		resp;	
	}
	
	public Response responsePUTMethodIncludedToken(String url, String tokenValue) {
		Response resp = RestAssured.given().header("Authorization", "Bearer " + tokenValue).and().header("Content-Type","application/json").put(url);
		return 		resp;	
	}
	
	public Response responsePOSTMethodSendBadRequestHeader(String url) {
		Response resp = RestAssured.given().header("Authorization", "Bearer ","Authorization", "Bearer ").post(url);
		return 		resp;	
	}
	public Response responseDELETEMethodSendBadRequestHeader(String url) {
		Response resp = RestAssured.given().header("Authorization", "Bearer ","Authorization", "Bearer ").delete(url);
		return 		resp;	
	}
	
	public Response responseDELETEMethodIncludedToken(String url, String tokenValue) {
		Response resp = RestAssured.given().header("Authorization", "Bearer " + tokenValue).delete(url);
		return 		resp;	
	}
	
	public void inputRequestBodyAPILogin(RequestSpecification httpRequest, String emailValue, String passwordValue)
	{
		JSONObject requestParams = new JSONObject();
		requestParams.put("email", emailValue);
		requestParams.put("password", passwordValue);		
		httpRequest.body(requestParams.toString());
	}
	
	public void inputRequestBodyAPICreateNewUser(RequestSpecification httpRequest, String nameValue, String jobValue)
	{
		JSONObject requestParams = new JSONObject();
		requestParams.put("name",nameValue);
		requestParams.put("job",jobValue);		
		httpRequest.body(requestParams.toString());
	}
	
	public void inputRequestBodyAPIEditNewUser(RequestSpecification httpRequest, String nameValue, String jobValue)
	{
		JSONObject requestParams = new JSONObject();
		requestParams.put("name",nameValue);
		requestParams.put("job",jobValue);		
		httpRequest.body(requestParams.toString());
	}
	

	
	public String getAttributeTypeStringFromResponse(Response response,String attributeName)
	{String attributeValue = "";
		JsonPath j = response.getBody().jsonPath();
		 attributeValue = j.get("'"+attributeName+"'");
		 
		return attributeValue;
	}


	public int getAttributeTypeIntFromResponse(Response response,String attributeName)
	{int attributeValue = 0;
		JsonPath j = response.getBody().jsonPath();
		 attributeValue = j.get("'"+attributeName+"'");
		 
		return attributeValue;
	}
	
}
