package Test.TestAPI;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import testSuite.*;

import utility.*;
import apiFunction.APIFunction;
/**
 * Unit test for simple App.
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({
	E2E_Test01.class,
	E2E_Test02.class
	
        	})
public class AppTest 
{}


